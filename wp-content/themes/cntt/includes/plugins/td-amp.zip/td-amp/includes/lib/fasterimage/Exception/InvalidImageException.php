<?php namespace FasterImage\Exception;

/**
 * Class InvalidImageException
 *
 * @package FasterImage\Exception
 */
class InvalidImageException extends \Exception {}